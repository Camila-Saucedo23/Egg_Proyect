/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia8ejercicio7;

import guia8ejercicio7.Entidad.Persona;
import guia8ejercicio7.Servicio.PersonaServicio;

/**
 *
 * @author diego
 */
public class Guia8Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        PersonaServicio peopleService = new PersonaServicio();
        System.out.println("Por favor ingrese la información de la persona 1");
        Persona gente1 = peopleService.crearPersona();
        System.out.println("Por favor ingrese la información de la persona 2");
        Persona gente2 = peopleService.crearPersona();
        System.out.println("Por favor ingrese la información de la persona 3");
        Persona gente3 = peopleService.crearPersona();
        System.out.println("Por favor ingrese la información de la persona 4");
        Persona gente4 = peopleService.crearPersona();

        int ideal = 0;
        int sobrepeso = 0;
        int bajopeso = 0;
        int mayorEdad = 0;
        int menorEdad = 0;
        
        Persona[] personas = new Persona[4];
        personas[0] = gente1;
        personas[1] = gente2;
        personas[2] = gente3;
        personas[3] = gente4;

        for (Persona elemento : personas) {
            if(elemento.getEdad() >= 18){
                mayorEdad ++;
            }else{
                menorEdad ++;
            }
            
            switch (peopleService.calcularIMC(elemento)) {
                case 0:
                    ideal ++;
                    break;
                case -1:
                    bajopeso ++;
                    break;
                default:
                    sobrepeso ++;
                    break;
            }
        }

        System.out.println("Información de " + gente1.getNombre());
        System.out.printf("La persona %s \n", (peopleService.calcularIMC(gente1) == 0) ? "tiene peso ideal" : (peopleService.calcularIMC(gente1)) == -1 ? "está por debajo del peso" : "tiene sobrepeso");
        System.out.printf("¿%s es mayor de edad? %b \n", gente1.getNombre(), peopleService.esMayorDeEdad(gente1));
        System.out.println("Información de " + gente2.getNombre());
        System.out.printf("La persona %s \n", (peopleService.calcularIMC(gente2) == 0) ? "tiene peso ideal" : (peopleService.calcularIMC(gente2)) == -1 ? "está por debajo del peso" : "tiene sobrepeso");
        System.out.printf("¿%s es mayor de edad? %b \n", gente2.getNombre(), peopleService.esMayorDeEdad(gente2));
        System.out.println("Información de " + gente3.getNombre());
        System.out.printf("La persona %s \n", (peopleService.calcularIMC(gente3) == 0) ? "tiene peso ideal" : (peopleService.calcularIMC(gente3)) == -1 ? "está por debajo del peso" : "tiene sobrepeso");
        System.out.printf("¿%s es mayor de edad? %b \n", gente3.getNombre(), peopleService.esMayorDeEdad(gente3));
        System.out.println("Información de " + gente4.getNombre());
        System.out.printf("La persona %s \n", (peopleService.calcularIMC(gente4) == 0) ? "tiene peso ideal" : (peopleService.calcularIMC(gente4)) == -1 ? "está por debajo del peso" : "tiene sobrepeso");
        System.out.printf("¿%s es mayor de edad? %b \n", gente4.getNombre(), peopleService.esMayorDeEdad(gente4));
        System.out.println("Personas mayores de edad: " + mayorEdad + " Personas menores de edad: " + menorEdad + " Personas en peso ideal: " + ideal + " Personas con sobrepeso: " + sobrepeso + " Personas con bajo peso: " + bajopeso);
    }

}
