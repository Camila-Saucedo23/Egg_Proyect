/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia8ejercicio7.Servicio;

import guia8ejercicio7.Entidad.Persona;
import java.util.Scanner;


/**
 *
 * @author diego
 */
public class PersonaServicio {
    
    public Persona crearPersona (){
        
        Scanner input = new Scanner(System.in);
        Persona people = new Persona();
        System.out.println("Por favor ingrese el nombre.");
        people.setNombre(input.next());
        System.out.println("Por favor ingrese la edad.");
        people.setEdad(input.nextInt());
        System.out.println("Por favor ingrese la letra correspondiente: H -> hombre, M -> mujer, O -> Otro");
        
        String gender;
        
        do {
            
            gender = input.next();
            if(!gender.equals("H") && !gender.equals("M") && !gender.equals("O")){
                System.out.println("Opción no permitida. Vuelva a intentarlo.");
            }
            
        } while (!gender.equals("H") && !gender.equals("M") && !gender.equals("O"));
        
        people.setSexo(gender);
        System.out.println("Por favor ingrese el peso");
        people.setPeso(input.nextDouble());
        System.out.println("Por favor ingrese la altura");
        people.setAltura(input.nextDouble());
        
        return people;
    }
    
    public int calcularIMC (Persona people){
        double IMC = people.getPeso() / (Math.pow(people.getAltura(), 2));
        return (IMC < 20) ? -1 : (IMC >= 20 && IMC <= 25) ? 0 : 1;
    }
    
    public boolean esMayorDeEdad (Persona people){
        return (people.getEdad() >= 18);
    }
}
